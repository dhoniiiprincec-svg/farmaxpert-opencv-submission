"""
FarmXpert - Edge-AI FastAPI Backend Server
Precision Agriculture Decision Support Engine

Run locally:
    pip install -r requirements.txt
    python edge_ai_server.py
or
    uvicorn edge_ai_server:app --reload --port 8000
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import random

app = FastAPI(
    title="FarmXpert Edge-AI API",
    description="Edge-AI Precision Agriculture REST API for Real-Time Telemetry & Decision Support",
    version="1.0.0"
)

# Enable CORS for frontend dashboard access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data Schemas
class SensorTelemetryInput(BaseModel):
    temperature: float = Field(32.5, description="Ambient air temperature in Celsius")
    humidity: float = Field(78.0, description="Relative humidity percentage")
    soil_moisture: float = Field(32.0, description="Root zone soil moisture percentage")
    light_intensity: float = Field(650.0, description="Ambient light in lux")
    soil_ph: Optional[float] = Field(6.8, description="Soil pH reading")
    zone_id: Optional[str] = Field("z2", description="Target zone identifier")

class EdgeAiDecisionOutput(BaseModel):
    temperature: float
    humidity: float
    soil_moisture: float
    light_intensity: float
    nutrition_status: str
    nutrient_deficiency: str
    disease_detected: bool
    disease_name: str
    disease_risk: str
    disease_severity: int
    irrigation_required: bool
    irrigation_zones: List[str]
    overall_risk: str
    recommendation: str

# Central Farm State
FARM_STATE = {
    "farm_info": {
        "farm_id": "farm-001",
        "farm_name": "Green Valley Farm",
        "farmer_name": "Arjun",
        "farmer_role": "Farmer",
        "total_area": "12.5 Acres",
        "crops": ["Tomato", "Chilli", "Brinjal"],
        "weather": {
            "temperature": 32,
            "condition": "Partly Cloudy",
            "icon": "cloud-sun"
        }
    },
    "top_priorities": {
        "nutrition": {
            "status": "MODERATE",
            "primary_deficiency": "Nitrogen Deficient",
            "description": "N Deficiency detected in",
            "affected_zones": ["Zone 2", "Zone 4"]
        },
        "disease": {
            "status": "HIGH RISK",
            "disease_name": "Leaf Blight Detected",
            "severity": 72,
            "affected_zones": ["Zone 2", "Zone 4"]
        },
        "irrigation": {
            "status": "IRRIGATION REQUIRED",
            "affected_zones": ["Zone 2", "Zone 4"],
            "next_irrigation": "Today Evening",
            "water_need": "18 mm"
        }
    },
    "zones": [
        {
            "zone_id": "z1",
            "zone_name": "Zone 1",
            "sector": "North Sector",
            "crop": "Tomato",
            "variety": "Arka Rakshak",
            "area": "3.2 Acres",
            "status_label": "Healthy",
            "status_type": "healthy",
            "plant_health": 92,
            "soil_moisture": 46,
            "temperature": 31.5,
            "humidity": 74,
            "light_intensity": 680,
            "nutrition_status": "OPTIMAL",
            "nutrient_deficiency": "None",
            "disease_detected": False,
            "disease_name": "None",
            "disease_risk": "LOW",
            "disease_severity": 0,
            "irrigation_required": False,
            "irrigation_priority": "Normal",
            "overall_risk": "LOW",
            "recommendation": "Soil moisture and foliage are healthy."
        },
        {
            "zone_id": "z2",
            "zone_name": "Zone 2",
            "sector": "East Sector",
            "crop": "Chilli",
            "variety": "Guntur Sannam",
            "area": "3.1 Acres",
            "status_label": "High Risk",
            "status_type": "risk",
            "plant_health": 46,
            "soil_moisture": 32,
            "temperature": 33.4,
            "humidity": 82,
            "light_intensity": 640,
            "nutrition_status": "DEFICIENT",
            "nutrient_deficiency": "Nitrogen",
            "disease_detected": True,
            "disease_name": "Leaf Blight",
            "disease_risk": "HIGH",
            "disease_severity": 72,
            "irrigation_required": True,
            "irrigation_priority": "High",
            "overall_risk": "HIGH",
            "recommendation": "Apply Copper fungicide immediately and irrigate 18 mm."
        },
        {
            "zone_id": "z3",
            "zone_name": "Zone 3",
            "sector": "South Sector",
            "crop": "Tomato",
            "variety": "Vaibhav Hybrid",
            "area": "3.4 Acres",
            "status_label": "Healthy",
            "status_type": "healthy",
            "plant_health": 89,
            "soil_moisture": 44,
            "temperature": 31.8,
            "humidity": 76,
            "light_intensity": 660,
            "nutrition_status": "OPTIMAL",
            "nutrient_deficiency": "None",
            "disease_detected": False,
            "disease_name": "None",
            "disease_risk": "LOW",
            "disease_severity": 0,
            "irrigation_required": False,
            "irrigation_priority": "Normal",
            "overall_risk": "LOW",
            "recommendation": "Crop growth on track."
        },
        {
            "zone_id": "z4",
            "zone_name": "Zone 4",
            "sector": "West Sector",
            "crop": "Brinjal",
            "variety": "Pusa Purple Long",
            "area": "2.8 Acres",
            "status_label": "Irrigation Needed",
            "status_type": "attention",
            "plant_health": 64,
            "soil_moisture": 24,
            "temperature": 33.1,
            "humidity": 72,
            "light_intensity": 670,
            "nutrition_status": "MODERATE",
            "nutrient_deficiency": "Nitrogen & Potassium",
            "disease_detected": False,
            "disease_name": "None",
            "disease_risk": "MODERATE",
            "disease_severity": 18,
            "irrigation_required": True,
            "irrigation_priority": "Urgent (Evening)",
            "overall_risk": "ATTENTION",
            "recommendation": "Soil moisture is low (24%). Irrigate 18 mm today evening."
        }
    ],
    "environmental": {
        "temperature": 32.5,
        "humidity": 78,
        "light_intensity": 650,
        "wind_speed": 12
    },
    "soil": {
        "soil_moisture": 32,
        "soil_ph": 6.8,
        "electrical_conductivity": 1.2,
        "soil_health": "Good"
    },
    "plant_health_score": {
        "overall_score": 68,
        "max_score": 100,
        "status": "MODERATE",
        "sub_metrics": {
            "growth_rate": {"label": "Growth Rate", "status": "Good", "value": 82},
            "leaf_health": {"label": "Leaf Health", "status": "Moderate", "value": 65},
            "stress_level": {"label": "Stress Level", "status": "Moderate", "value": 60}
        }
    },
    "alerts": [
        {
            "id": "alt-001",
            "title": "High Disease Risk in Zone 2",
            "description": "Leaf Blight is spreading. Immediate action required.",
            "status": "High Risk",
            "type": "danger",
            "time": "10 mins ago",
            "zone": "Zone 2",
            "action": "Inspect & Spray Fungicide"
        },
        {
            "id": "alt-002",
            "title": "Soil Moisture Low in Zone 4",
            "description": "Soil moisture dropped below optimal level.",
            "status": "Attention",
            "type": "warning",
            "time": "25 mins ago",
            "zone": "Zone 4",
            "action": "Trigger Drip Irrigation"
        }
    ],
    "ai_recommendations": [
        {"id": "rec-1", "number": 1, "text": "Irrigate Zone 2 and Zone 4 today evening."},
        {"id": "rec-2", "number": 2, "text": "Apply nitrogen fertilizer in Zone 2."},
        {"id": "rec-3", "number": 3, "text": "Inspect plants in Zone 2 for Leaf Blight."},
        {"id": "rec-4", "number": 4, "text": "Maintain soil moisture between 30% – 60%."}
    ],
    "historical_trends": {
        "7days": {
            "labels": ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5", "Day 6", "Today"],
            "overall_health": [82, 80, 78, 74, 71, 69, 68],
            "disease_risk": [15, 18, 25, 42, 58, 68, 72],
            "soil_moisture": [52, 48, 45, 39, 36, 34, 32]
        },
        "24hours": {
            "labels": ["00:00", "04:00", "08:00", "12:00", "16:00", "20:00", "Now"],
            "overall_health": [70, 70, 69, 68, 68, 68, 68],
            "disease_risk": [65, 66, 68, 70, 72, 72, 72],
            "soil_moisture": [38, 37, 35, 33, 32, 32, 32]
        },
        "30days": {
            "labels": ["Week 1", "Week 2", "Week 3", "Week 4", "Current"],
            "overall_health": [88, 85, 80, 72, 68],
            "disease_risk": [10, 15, 30, 55, 72],
            "soil_moisture": [58, 52, 46, 38, 32]
        }
    },
    "quick_summary": {
        "total_plants": "5,420",
        "healthy_plants": "76%",
        "diseased_plants": "12%",
        "water_used_today": "1,250 L",
        "estimated_yield": "2.8 Tons/acre"
    }
}

# REST Endpoints
@app.get("/api/v1/health")
def health_check():
    return {"status": "healthy", "service": "FarmXpert Edge-AI Engine", "version": "1.0.0"}

@app.get("/api/v1/farm/overview")
def get_farm_overview():
    return FARM_STATE

@app.get("/api/v1/zones/{zone_id}")
def get_zone_data(zone_id: str):
    for zone in FARM_STATE["zones"]:
        if zone["zone_id"] == zone_id or zone["zone_name"].lower() == zone_id.lower():
            return zone
    raise HTTPException(status_code=404, detail="Zone not found")

@app.get("/api/v1/sensors/telemetry")
def get_sensors_telemetry():
    return {
        "environmental": FARM_STATE["environmental"],
        "soil": FARM_STATE["soil"]
    }

@app.get("/api/v1/plant-health")
def get_plant_health():
    return FARM_STATE["plant_health_score"]

@app.get("/api/v1/nutrition/status")
def get_nutrition_status():
    return FARM_STATE["top_priorities"]["nutrition"]

@app.get("/api/v1/disease/risk")
def get_disease_risk():
    return FARM_STATE["top_priorities"]["disease"]

@app.get("/api/v1/irrigation/recommendation")
def get_irrigation_recommendation():
    return FARM_STATE["top_priorities"]["irrigation"]

@app.get("/api/v1/alerts")
def get_alerts():
    return FARM_STATE["alerts"]

@app.get("/api/v1/recommendations")
def get_recommendations():
    return FARM_STATE["ai_recommendations"]

@app.get("/api/v1/trends")
def get_historical_trends(range: str = "7days"):
    return FARM_STATE["historical_trends"].get(range, FARM_STATE["historical_trends"]["7days"])

@app.post("/api/v1/inference/predict", response_model=EdgeAiDecisionOutput)
def run_edge_ai_inference(telemetry: SensorTelemetryInput):
    """
    Edge-AI Decision Engine:
    SENSE -> ANALYZE -> PREDICT -> RECOMMEND -> ALERT
    """
    # Precision Irrigation Decision
    irrigation_required = telemetry.soil_moisture < 35.0
    irrigation_zones = ["Zone 2", "Zone 4"] if irrigation_required else []

    # Disease Risk Estimation (High humidity + elevated temp)
    disease_risk = "HIGH" if (telemetry.humidity > 75 and telemetry.temperature > 30) else "LOW"
    disease_detected = disease_risk == "HIGH"
    disease_severity = 72 if disease_detected else 12

    # Nutrition Deficiency
    nutrition_status = "MODERATE"
    nutrient_deficiency = "Nitrogen"

    overall_risk = "HIGH" if disease_detected else ("ATTENTION" if irrigation_required else "LOW")
    recommendation = "Irrigation required" if irrigation_required else "Maintain standard fertigation"

    return EdgeAiDecisionOutput(
        temperature=telemetry.temperature,
        humidity=telemetry.humidity,
        soil_moisture=telemetry.soil_moisture,
        light_intensity=telemetry.light_intensity,
        nutrition_status=nutrition_status,
        nutrient_deficiency=nutrient_deficiency,
        disease_detected=disease_detected,
        disease_name="Leaf Blight" if disease_detected else "None",
        disease_risk=disease_risk,
        disease_severity=disease_severity,
        irrigation_required=irrigation_required,
        irrigation_zones=irrigation_zones,
        overall_risk=overall_risk,
        recommendation=recommendation
    )

if __name__ == "__main__":
    import uvicorn
    print("🌾 Starting FarmXpert Edge-AI Backend Server on http://localhost:8000 ...")
    uvicorn.run(app, host="0.0.0.0", port=8000)
