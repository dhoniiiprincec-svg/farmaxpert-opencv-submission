/**
 * FarmXpert - Main Application Controller
 * Connects UI, Services, Map, Gauges, Charts, and Live Stream.
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Initialize Renderers
  const zoneMapRenderer = new FarmZoneMapRenderer('zoneMapCanvas');
  const healthGauge = new PlantHealthGauge('gaugeCanvasContainer', 'gaugeBreakdownContainer');
  const trendChart = new FarmTrendChart('trendChartContainer');

  // DOM Elements
  const refreshBtn = document.getElementById('refreshBtn');
  const edgeApiBadge = document.getElementById('edgeApiBadge');
  const statusBanner = document.getElementById('statusBanner');
  const statusBannerText = document.getElementById('statusBannerText');
  const mobileMenuToggle = document.getElementById('mobileMenuToggle');
  const sidebar = document.getElementById('appSidebar');

  // Load initial data
  const data = await window.apiService.getFarmOverview();
  renderDashboard(data);

  // Initialize Map, Gauge & Chart
  zoneMapRenderer.init(data.zones);
  healthGauge.render(data.plant_health_score);
  trendChart.init(data.historical_trends['7days'], '7days');

  // Listen for API / Stream updates
  window.apiService.subscribe((event, payload) => {
    if (event === 'data_updated') {
      renderDashboard(payload);
      zoneMapRenderer.update(payload.zones);
      healthGauge.render(payload.plant_health_score);
    } else if (event === 'connection_change') {
      updateConnectionStatus(payload.connected);
    }
  });

  // Start live polling / simulation loop
  window.apiService.startPolling((updated) => {
    renderDashboard(updated);
  });

  // Initial connection test
  window.apiService.testConnection();

  /**
   * Main Dashboard Data Binding Function
   */
  function renderDashboard(d) {
    if (!d) return;

    // 1. Environmental Telemetry
    if (d.environmental) {
      document.getElementById('envTemp').textContent = `${d.environmental.temperature}°C`;
      document.getElementById('envHum').textContent = `${d.environmental.humidity}%`;
      document.getElementById('envLight').textContent = `${d.environmental.light_intensity} lux`;
      document.getElementById('envWind').textContent = `${d.environmental.wind_speed} km/h`;
    }

    // 2. Soil Telemetry
    if (d.soil) {
      document.getElementById('soilMoist').textContent = `${d.soil.soil_moisture}%`;
      document.getElementById('soilPh').textContent = `${d.soil.soil_ph} pH`;
      document.getElementById('soilEc').textContent = `${d.soil.electrical_conductivity} dS/m`;
      document.getElementById('soilHealth').textContent = d.soil.soil_health;
    }

    // 3. Top Priority 1: Plant Nutrition Status
    if (d.top_priorities?.nutrition) {
      const nut = d.top_priorities.nutrition;
      document.getElementById('nutStatusBadge').textContent = nut.status;
      document.getElementById('nutHeadline').textContent = nut.primary_deficiency;
      document.getElementById('nutZones').textContent = nut.affected_zones.join(', ');
    }

    // 4. Top Priority 2: Disease Detection & Risk
    if (d.top_priorities?.disease) {
      const dis = d.top_priorities.disease;
      document.getElementById('disStatusBadge').textContent = dis.status;
      document.getElementById('disHeadline').textContent = dis.disease_name;
      document.getElementById('disSeverityVal').textContent = `${dis.severity}%`;
      document.getElementById('disSeverityBar').style.width = `${dis.severity}%`;
      document.getElementById('disZones').textContent = dis.affected_zones.join(', ');
    }

    // 5. Top Priority 3: Irrigation Recommendation
    if (d.top_priorities?.irrigation) {
      const irg = d.top_priorities.irrigation;
      document.getElementById('irgStatusBadge').textContent = irg.status;
      document.getElementById('irgHeadline').textContent = irg.affected_zones.join(', ');
      document.getElementById('irgNext').textContent = irg.next_irrigation;
      document.getElementById('irgNeed').textContent = irg.water_need;
    }

    // 6. Quick Summary (Bottom 5 Cards)
    if (d.quick_summary) {
      document.getElementById('sumTotalPlants').textContent = d.quick_summary.total_plants;
      document.getElementById('sumHealthyPlants').textContent = d.quick_summary.healthy_plants;
      document.getElementById('sumDiseasedPlants').textContent = d.quick_summary.diseased_plants;
      document.getElementById('sumWaterUsed').textContent = d.quick_summary.water_used_today;
      document.getElementById('sumYield').textContent = d.quick_summary.estimated_yield;
    }
  }

  function updateConnectionStatus(isConnected) {
    if (isConnected) {
      if (edgeApiBadge) {
        edgeApiBadge.innerHTML = `<span class="pulse-dot"></span> <span>Edge-AI Live</span>`;
        edgeApiBadge.style.borderColor = 'rgba(16, 185, 129, 0.4)';
        edgeApiBadge.style.color = '#34d399';
      }
      if (statusBanner) {
        statusBanner.className = 'status-banner banner-connected';
        statusBannerText.innerHTML = `<strong>Edge-AI Connected:</strong> Receiving real-time inference telemetry from VS Code Python module.`;
      }
    } else {
      if (edgeApiBadge) {
        edgeApiBadge.innerHTML = `<span class="pulse-dot" style="background:#f59e0b; box-shadow:0 0 8px #f59e0b;"></span> <span>Edge-AI Simulator</span>`;
        edgeApiBadge.style.borderColor = 'rgba(245, 158, 11, 0.4)';
        edgeApiBadge.style.color = '#fbbf24';
      }
      if (statusBanner) {
        statusBanner.className = 'status-banner';
        statusBannerText.innerHTML = `<strong>Edge-AI connection unavailable:</strong> Displaying latest available data & live simulated telemetry.`;
      }
    }
  }

  // Event Listeners
  // 1. Manual Refresh Button
  refreshBtn?.addEventListener('click', async () => {
    refreshBtn.classList.add('spin-animation');
    const fresh = await window.apiService.getFarmOverview();
    renderDashboard(fresh);
    zoneMapRenderer.update(fresh.zones);
    healthGauge.render(fresh.plant_health_score);
    window.modalManager.showToast('Dashboard synchronized with latest telemetry', 'success');
    setTimeout(() => refreshBtn.classList.remove('spin-animation'), 600);
  });

  // 2. Edge API Badge click -> opens API settings modal
  edgeApiBadge?.addEventListener('click', () => {
    window.modalManager.openApiConfigModal();
  });

  // 3. Time Filter Buttons for Chart
  document.querySelectorAll('.time-filter-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      document.querySelectorAll('.time-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const range = btn.getAttribute('data-range');
      const trendData = await window.apiService.getHistoricalTrends(range);
      trendChart.setRangeData(range, trendData);
    });
  });

  // 4. NDVI Map Toggle Button
  document.getElementById('toggleNdviBtn')?.addEventListener('click', function() {
    const isNdvi = zoneMapRenderer.toggleNdviMode();
    this.textContent = isNdvi ? '🌿 Normal View' : '🛰️ NDVI View';
    this.classList.toggle('btn-primary', isNdvi);
    this.classList.toggle('btn-outline', !isNdvi);
  });

  // 5. Navigation Items Switching
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      const page = item.getAttribute('data-page');

      if (page !== 'overview') {
        window.modalManager.showToast(`Switched view to ${item.textContent.trim()}`, 'info');
      }

      // Close mobile sidebar if open
      if (window.innerWidth <= 768) {
        sidebar.classList.remove('mobile-open');
      }
    });
  });

  // 6. Mobile Menu Toggle
  mobileMenuToggle?.addEventListener('click', () => {
    sidebar.classList.toggle('mobile-open');
  });

  // 7. Notification Bell & Profile Dropdown
  document.getElementById('notifBellBtn')?.addEventListener('click', () => {
    window.modalManager.openAllAlertsModal();
  });

  document.getElementById('userProfileCard')?.addEventListener('click', () => {
    window.modalManager.openFarmSwitcherModal();
  });
});
